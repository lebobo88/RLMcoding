# Project Idea

**Session:** DISC-20251126194840
**Captured:** 2025-11-26T19:48:40.126Z
**Domain:** Not specified
**Existing Codebase:** None (greenfield)

## Raw Idea

i want a universal authentication service allowing for email/password, google, and github authentication that any app can use.

## Metadata

- Mode: auto
- Skip Questions: false
