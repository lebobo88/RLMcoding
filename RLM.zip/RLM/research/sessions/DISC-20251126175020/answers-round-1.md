# Answers - Round 1

## Q1
**Answer:** internal use

## Q2
**Answer:** small to medium

## Q3
**Answer:** me

## Q4
**Answer:** no

## Q5
**Answer:** local hosted security and privacy
