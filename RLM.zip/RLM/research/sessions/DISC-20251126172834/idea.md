# Project Idea

**Session:** DISC-20251126172834
**Captured:** 2025-11-26T17:28:34.399Z
**Domain:** Not specified
**Existing Codebase:** None (greenfield)

## Raw Idea

i want a universal authentication service allowing for email/password, google, and github authentication that any app can use.



## Metadata

- Mode: guided
- Skip Questions: false
