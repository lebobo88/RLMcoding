# Project Idea

**Session:** DISC-20251126171342
**Captured:** 2025-11-26T17:13:42.327Z
**Domain:** Not specified
**Existing Codebase:** None (greenfield)

## Raw Idea

i want a universal authentication service allowing for email/password, google, and github authentication that any app can use.



## Metadata

- Mode: guided
- Skip Questions: false
